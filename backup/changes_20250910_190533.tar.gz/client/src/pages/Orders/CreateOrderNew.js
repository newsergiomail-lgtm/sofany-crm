import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from 'react-query';
import { 
  ArrowLeft, 
  Save,
  Plus,
  User,
  DollarSign,
  FileText,
  Clock,
  CheckCircle,
  Package,
  Shield
} from 'lucide-react';
import { ordersAPI, customersAPI } from '../../services/api';
import LoadingSpinner from '../../components/UI/LoadingSpinner';
import toast from 'react-hot-toast';

const CreateOrderNew = () => {
  const navigate = useNavigate();

  // Состояния для форм
  const [clientForm, setClientForm] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    floor: '',
    comment: '',
    hasFreightElevator: false,
    company: '',
    // Доп. контакты и доставка (для синхронизации со шторкой)
    additionalContact: '',
    preferredChannel: '',
    deliveryTimeWindow: '',
    deliveryMethod: '',
    deliveryCost: ''
  });

  const [financialForm, setFinancialForm] = useState({
    totalAmount: 0,
    prepaymentDate: '',
    prepaymentAmount: 0,
    prepaymentPercent: 0,
    isCashPayment: false,
    // Доп. финполя
    paymentMethod: '',
    invoiceNumber: '',
    finalPaymentDate: '',
    paymentComment: ''
  });

  const [orderForm, setOrderForm] = useState({
    orderNumber: '',
    manager: 'Анна Петрова',
    creationDate: new Date().toISOString().split('T')[0],
    deadline: '',
    status: 'new',
    priority: 'normal'
  });

  // Состояние для предиктивного ввода
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  // Статусы заказа
  const orderStatuses = [
    {
      id: 'new',
      title: 'Новый',
      description: 'Заказ только что создан',
      icon: CheckCircle,
      color: 'teal'
    },
    {
      id: 'confirmed',
      title: 'Принят',
      description: 'Заказ подтвержден',
      icon: FileText,
      color: 'blue'
    },
    {
      id: 'purchase',
      title: 'В закупке',
      description: 'Закупка материалов',
      icon: Package,
      color: 'orange'
    },
    {
      id: 'production',
      title: 'В производство',
      description: 'Изготовление изделия',
      icon: Shield,
      color: 'green'
    }
  ];

  // Состояния для позиций заказа
  const [orderItems, setOrderItems] = useState([
    { id: 1, name: '', quantity: 1, price: 0, total: 0 }
  ]);

  // Описание проекта
  const [projectName, setProjectName] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [projectRequirements, setProjectRequirements] = useState('');

  // Файлы (будут загружены после создания заказа)
  const [selectedFiles, setSelectedFiles] = useState([]); // Array<File>
  const [uploading, setUploading] = useState(false);

  // Мутация для создания заказа
  const createOrderMutation = useMutation(ordersAPI.create, {
    onSuccess: () => {
      // навигацию и загрузку файлов выполняем в handleSave через mutateAsync
    },
    onError: (error) => {
      console.error('Ошибка создания заказа:', error);
      const msg = error?.response?.data?.message || 'Ошибка при создании заказа';
      toast.error(msg);
    }
  });

  // Генерация номера заказа
  useEffect(() => {
    const generateOrderNumber = () => {
      const prefix = 'SOF';
      const year = new Date().getFullYear();
      const random = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
      return `${prefix}-${year}-${random}`;
    };
    
    setOrderForm(prev => ({ ...prev, orderNumber: generateOrderNumber() }));
  }, []);

  // Обработчики изменения форм
  const handleClientChange = (field, value) => {
    setClientForm(prev => ({ ...prev, [field]: value }));
  };

  const handleFinancialChange = (field, value) => {
    setFinancialForm(prev => ({ ...prev, [field]: value }));
    
    // Автоматический расчет процента предоплаты
    if (field === 'prepaymentAmount' && financialForm.totalAmount > 0) {
      const percent = Math.round((value / financialForm.totalAmount) * 100);
      setFinancialForm(prev => ({ ...prev, prepaymentPercent: percent }));
    }
  };

  const handleOrderChange = (field, value) => {
    setOrderForm(prev => ({ ...prev, [field]: value }));
  };

  const handleStatusChange = (statusId) => {
    setOrderForm(prev => ({ ...prev, status: statusId }));
  };

  // Работа с файлами (до создания заказа)
  const allowedExtensions = ['.pdf', '.dwg', '.dxf', '.skp', '.jpg', '.jpeg', '.png'];
  const addFiles = (files) => {
    const incoming = Array.from(files || []);
    const valid = incoming.filter(f => {
      const ext = '.' + (f.name.split('.').pop() || '').toLowerCase();
      return allowedExtensions.includes(ext);
    });
    if (valid.length !== incoming.length) {
      toast.error('Некоторые файлы отклонены. Разрешены: PDF, DWG, DXF, SKP, JPG, PNG');
    }
    if (valid.length > 0) {
      setSelectedFiles(prev => [...prev, ...valid]);
    }
  };
  const handleFileInput = (e) => addFiles(e.target.files);
  const handleDrop = (e) => {
    e.preventDefault();
    addFiles(e.dataTransfer.files);
  };
  const handleDragOver = (e) => e.preventDefault();
  const removeSelectedFile = (index) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Обработчики для позиций заказа
  const handleItemChange = (itemId, field, value) => {
    setOrderItems(prev => prev.map(item => {
      if (item.id === itemId) {
        const updatedItem = { ...item, [field]: value };
        if (field === 'quantity' || field === 'price') {
          updatedItem.total = updatedItem.quantity * updatedItem.price;
        }
        return updatedItem;
      }
      return item;
    }));
  };

  const addOrderItem = () => {
    const newItem = {
      id: Date.now(),
      name: '',
      quantity: 1,
      price: 0,
      total: 0
    };
    setOrderItems(prev => [...prev, newItem]);
  };

  const removeOrderItem = (itemId) => {
    if (orderItems.length > 1) {
      setOrderItems(prev => prev.filter(item => item.id !== itemId));
    }
  };

  // Расчет общей суммы
  const calculateTotal = () => {
    return orderItems.reduce((sum, item) => sum + item.total, 0);
  };

  // Обеспечить customer_id: взять сохраненный, первый из базы или создать тестового
  const ensureCustomerId = async () => {
    const cached = localStorage.getItem('default_customer_id');
    if (cached) return Number(cached);

    try {
      const res = await customersAPI.getAll({ page: 1, limit: 1 });
      const list = res?.data?.customers || res?.data?.data || res?.data || [];
      const first = Array.isArray(list) ? list[0] : null;
      if (first?.id) {
        localStorage.setItem('default_customer_id', String(first.id));
        return first.id;
      }
    } catch (_) {}

    // Создаем тестового клиента, если никого нет
    try {
      const createRes = await customersAPI.create({
        name: clientForm.name || 'Тестовый клиент',
        phone: clientForm.phone || '+7 999 999 99 99',
        email: clientForm.email || 'test@example.com'
      });
      const id = createRes?.data?.customer?.id || createRes?.data?.id;
      if (id) {
        localStorage.setItem('default_customer_id', String(id));
        return id;
      }
    } catch (_) {}

    // Фолбэк
    throw new Error('Не удалось определить клиента (customer_id)');
  };

  // Сохранение заказа (соответствие серверной схеме Joi)
  const handleSave = async () => {
    try {
      const customerId = await ensureCustomerId();

      // Преобразуем позиции к полям API
      const items = orderItems
        .filter(i => (i.name || '').trim().length > 0)
        .map(i => ({
          name: i.name,
          description: '',
          quantity: Number(i.quantity) || 1,
          unit_price: Number(i.price) || 0,
        }));

      if (items.length === 0) {
        toast.error('Добавьте хотя бы одну позицию');
        return;
      }

      const apiBody = {
        customer_id: customerId,
        product_name: items[0]?.name || '',
        status: orderForm.status || 'new',
        priority: orderForm.priority === 'medium' ? 'normal' : (orderForm.priority || 'normal'),
        delivery_date: orderForm.deadline || null,
        notes: clientForm.comment || '',
        project_description: projectDescription || '',
        // плоские поля клиента/доставки
        customer_name: clientForm.name || null,
        customer_phone: clientForm.phone || null,
        customer_email: clientForm.email || null,
        customer_company: clientForm.company || null,
        delivery_address: clientForm.address || null,
        has_elevator: !!clientForm.hasFreightElevator,
        floor: clientForm.floor || null,
        delivery_notes: clientForm.comment || null,
        calculator_data: {
          project_name: projectName || '',
          project_requirements: projectRequirements || '',
          // контакты
          additional_contact: clientForm.additionalContact || '',
          preferred_channel: clientForm.preferredChannel || '',
          // доставка
          delivery_time_window: clientForm.deliveryTimeWindow || '',
          delivery_method: clientForm.deliveryMethod || '',
          delivery_cost: Number(clientForm.deliveryCost || 0),
          // финансы
          payment_method: financialForm.paymentMethod || '',
          prepayment_date: financialForm.prepaymentDate || '',
          invoice_number: financialForm.invoiceNumber || '',
          final_payment_date: financialForm.finalPaymentDate || '',
          payment_comment: financialForm.paymentComment || ''
        },
        items,
      };

      // Создаём заказ и дожидаемся результата
      const data = await createOrderMutation.mutateAsync(apiBody);
      const newId = data?.order?.id || data?.id;
      if (!newId) {
        toast.error('Не удалось получить ID созданного заказа');
        return;
      }

      // Загрузка выбранных файлов после создания заказа
      if (selectedFiles.length > 0) {
        setUploading(true);
        try {
          for (const file of selectedFiles) {
            const formData = new FormData();
            formData.append('drawing', file);
            await ordersAPI.uploadDrawing(newId, formData);
          }
          toast.success('Файлы загружены');
        } catch (e) {
          console.error('Ошибка загрузки файлов:', e);
          toast.error('Не все файлы удалось загрузить');
        } finally {
          setUploading(false);
          setSelectedFiles([]);
        }
      }

      toast.success('Заказ успешно создан!');
      navigate(`/orders/${newId}`, { state: { created: true } });
    } catch (e) {
      const msg = e?.message || 'Ошибка подготовки данных заказа';
      toast.error(msg);
    }
  };

  if (createOrderMutation.isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-200">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/orders')}
              className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Назад к заказам
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Создание нового заказа</h1>
              <p className="text-gray-600">Заполните информацию о заказе</p>
            </div>
          </div>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-3 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors font-medium"
            disabled={createOrderMutation.isLoading}
          >
            <Save className="h-4 w-4" />
            Сохранить заказ
          </button>
        </div>

        <div className="flex gap-6">
          {/* Основная колонка */}
          <div className="flex-1 space-y-6">
            {/* Клиент и доставка */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-6">
                <User className="h-6 w-6 text-teal-600" />
                <h2 className="text-xl font-semibold text-gray-900">Клиент и доставка</h2>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">ФИО клиента</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="Иванов Иван Иванович"
                    value={clientForm.name}
                    onChange={(e) => handleClientChange('name', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Телефон</label>
                  <input
                    type="tel"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="+7 (900) 123-45-67"
                    value={clientForm.phone}
                    onChange={(e) => handleClientChange('phone', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="client@example.com"
                    value={clientForm.email}
                    onChange={(e) => handleClientChange('email', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Компания</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="ООО Пример"
                    value={clientForm.company}
                    onChange={(e) => handleClientChange('company', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Адрес доставки</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="г. Москва, ул. Примерная, д. 1"
                    value={clientForm.address}
                    onChange={(e) => handleClientChange('address', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Этаж</label>
                  <input
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="1"
                    value={clientForm.floor}
                    onChange={(e) => handleClientChange('floor', e.target.value)}
                  />
                </div>
              </div>
              <div className="mt-2">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={clientForm.hasFreightElevator}
                    onChange={(e) => handleClientChange('hasFreightElevator', e.target.checked)}
                    className="w-4 h-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                  />
                  <span className="text-sm font-medium text-gray-700">Грузовой лифт есть</span>
                </label>
              </div>
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Комментарий</label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                  rows={3}
                  placeholder="Дополнительная информация..."
                  value={clientForm.comment}
                  onChange={(e) => handleClientChange('comment', e.target.value)}
                />
              </div>

              {/* Доп. контакт и предпочтительный канал связи */}
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Доп. контакт</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="Имя, телефон"
                    value={clientForm.additionalContact}
                    onChange={(e) => handleClientChange('additionalContact', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Канал связи</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={clientForm.preferredChannel}
                    onChange={(e) => handleClientChange('preferredChannel', e.target.value)}
                  >
                    <option value="">—</option>
                    <option value="phone">Телефон</option>
                    <option value="email">Email</option>
                    <option value="telegram">Telegram</option>
                    <option value="whatsapp">WhatsApp</option>
                    <option value="viber">Viber</option>
                  </select>
                </div>
              </div>

              {/* Параметры доставки из шторки */}
              <div className="grid grid-cols-3 gap-4 mt-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Окно доставки</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={clientForm.deliveryTimeWindow}
                    onChange={(e) => handleClientChange('deliveryTimeWindow', e.target.value)}
                  >
                    <option value="">—</option>
                    <option value="09:00-12:00">09:00 - 12:00</option>
                    <option value="12:00-15:00">12:00 - 15:00</option>
                    <option value="14:00-18:00">14:00 - 18:00</option>
                    <option value="18:00-21:00">18:00 - 21:00</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Способ доставки</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={clientForm.deliveryMethod}
                    onChange={(e) => handleClientChange('deliveryMethod', e.target.value)}
                  >
                    <option value="">—</option>
                    <option value="pickup">Самовывоз</option>
                    <option value="courier">Курьер</option>
                    <option value="transport">ТК</option>
                    <option value="post">Почта</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Стоимость доставки (₽)</label>
                  <input
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="0"
                    value={clientForm.deliveryCost}
                    onChange={(e) => handleClientChange('deliveryCost', e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Финансы */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-6">
                <DollarSign className="h-6 w-6 text-teal-600" />
                <h2 className="text-xl font-semibold text-gray-900">Финансы</h2>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Сумма сделки (₽)</label>
                  <input
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="0"
                    value={financialForm.totalAmount}
                    onChange={(e) => handleFinancialChange('totalAmount', parseFloat(e.target.value) || 0)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Дата предоплаты</label>
                  <input
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={financialForm.prepaymentDate}
                    onChange={(e) => handleFinancialChange('prepaymentDate', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Сумма предоплаты (₽)</label>
                  <input
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="0"
                    value={financialForm.prepaymentAmount}
                    onChange={(e) => handleFinancialChange('prepaymentAmount', parseFloat(e.target.value) || 0)}
                  />
                </div>
              </div>
              
              <div className="mt-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">Процент предоплаты</span>
                  <span className="text-sm font-semibold text-teal-600">{financialForm.prepaymentPercent}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={financialForm.prepaymentPercent}
                  onChange={(e) => {
                    const percent = parseInt(e.target.value);
                    setFinancialForm(prev => ({ 
                      ...prev, 
                      prepaymentPercent: percent,
                      prepaymentAmount: Math.round((prev.totalAmount * percent) / 100)
                    }));
                  }}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>

              <div className="mt-6">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700">Оплата наличными</span>
                  <label className="relative inline-block w-12 h-7 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={financialForm.isCashPayment}
                      onChange={(e) => handleFinancialChange('isCashPayment', e.target.checked)}
                      className="opacity-0 w-0 h-0"
                    />
                    <span className={`absolute cursor-pointer top-0 left-0 right-0 bottom-0 transition-all duration-300 rounded-full ${
                      financialForm.isCashPayment ? 'bg-teal-600' : 'bg-gray-300'
                    }`}>
                      <span className={`absolute content-[''] h-5 w-5 left-1 bottom-1 bg-white transition-all duration-300 rounded-full ${
                        financialForm.isCashPayment ? 'transform translate-x-5' : ''
                      }`} />
                    </span>
                  </label>
                </div>
              </div>

              {/* Фин. реквизиты из шторки */}
              <div className="grid grid-cols-2 gap-4 mt-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Способ оплаты</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={financialForm.paymentMethod}
                    onChange={(e) => handleFinancialChange('paymentMethod', e.target.value)}
                  >
                    <option value="">—</option>
                    <option value="bank_transfer">Банковский перевод</option>
                    <option value="cash">Наличные</option>
                    <option value="card">Карта</option>
                    <option value="installment">Рассрочка</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Номер счета</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="INV-001"
                    value={financialForm.invoiceNumber}
                    onChange={(e) => handleFinancialChange('invoiceNumber', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Дата фин. оплаты</label>
                  <input
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={financialForm.finalPaymentDate}
                    onChange={(e) => handleFinancialChange('finalPaymentDate', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Комментарий к оплате</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    placeholder="Комментарий"
                    value={financialForm.paymentComment}
                    onChange={(e) => handleFinancialChange('paymentComment', e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Описание проекта (как в OrderDetail) */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex justify-between items-center mb-5 pb-3 border-b border-gray-100">
                <h2 className="text-xl font-semibold text-gray-900">Описание проекта</h2>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Название проекта</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder='Например: Диван "Неаполь" с аккордеоном'
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Описание</label>
                  <textarea
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:border-teal-500 focus:ring-2 focus:ring-teal-200 min-h-[120px]"
                    value={projectDescription}
                    onChange={(e) => setProjectDescription(e.target.value)}
                    placeholder="Краткое описание изделия, материалы, цвет, размеры и т.п."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Особые требования</label>
                  <textarea
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:border-teal-500 focus:ring-2 focus:ring-teal-200"
                    value={projectRequirements}
                    onChange={(e) => setProjectRequirements(e.target.value)}
                    placeholder="Например: доставка в разобранном виде, гарантия, сборка..."
                  />
                </div>

                {/* Чертежи и документы */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">Чертежи и документы</h3>
                    <div>
                      <input
                        id="fileInputCreate"
                        type="file"
                        multiple
                        accept=".pdf,.dwg,.dxf,.skp,.jpg,.jpeg,.png"
                        onChange={handleFileInput}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => document.getElementById('fileInputCreate').click()}
                        className="px-3 py-2 bg-teал-600 text-white rounded-lg hover:bg-teal-700 text-sm"
                      >
                        Добавить файл
                      </button>
                    </div>
                  </div>

                  <div
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    className={`border-2 border-dashed rounded-xl p-6 text-center ${selectedFiles.length ? 'border-teal-300 bg-teal-50' : 'border-gray-300 hover:border-teal-400'}`}
                  >
                    <p className="text-gray-600 text-sm">Перетащите файлы сюда или нажмите «Добавить файл»</p>
                    <p className="text-xs text-gray-500 mt-1">Поддержка: PDF, DWG, DXF, SKP, JPG, PNG</p>
                  </div>

                  {selectedFiles.length > 0 && (
                    <div className="mt-4 border border-gray-100 rounded-lg divide-y">
                      {selectedFiles.map((f, idx) => (
                        <div key={idx} className="flex items-center justify-between px-3 py-2">
                          <div className="text-sm text-gray-800 truncate mr-3">{f.name}</div>
                          <div className="flex items-center gap-3">
                            {uploading ? (
                              <span className="text-xs text-gray-500">Загрузка...</span>
                            ) : (
                              <button type="button" onClick={() => removeSelectedFile(idx)} className="text-red-600 text-sm hover:underline">Удалить</button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Детали заказа */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-6">
                <FileText className="h-6 w-6 text-teal-600" />
                <h2 className="text-xl font-semibold text-gray-900">Детали заказа</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">Наименование</th>
                      <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider w-20">Кол-во</th>
                      <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider w-32">Цена (₽)</th>
                      <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider w-20">Сумма (₽)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderItems.map((item) => (
                      <tr key={item.id} className="border-b border-gray-100">
                        <td className="py-3 px-2">
                          <input
                            type="text"
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                            placeholder="Наименование товара"
                            value={item.name}
                            onChange={(e) => handleItemChange(item.id, 'name', e.target.value)}
                          />
                        </td>
                        <td className="py-3 px-2">
                          <input
                            type="number"
                            className="w-full px-2 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-center"
                            placeholder="1"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleItemChange(item.id, 'quantity', parseInt(e.target.value) || 0)}
                          />
                        </td>
                        <td className="py-3 px-2">
                          <input
                            type="number"
                            className="w-full px-2 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 text-right"
                            placeholder="0"
                            min="0"
                            step="0.01"
                            value={item.price}
                            onChange={(e) => handleItemChange(item.id, 'price', parseFloat(e.target.value) || 0)}
                          />
                        </td>
                        <td className="py-3 px-2">
                          <input
                            type="text"
                            className="w-full px-2 py-2 text-sm border border-transparent bg-gray-50 rounded-lg text-right"
                            value={item.total.toLocaleString()}
                            readOnly
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t-2 border-gray-200 bg-gray-50">
                      <td className="py-3 px-2 font-medium text-sm text-gray-900" colSpan="3">ИТОГО</td>
                      <td className="py-3 px-2 font-semibold text-sm text-gray-900">{calculateTotal().toLocaleString()} ₽</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <button
                onClick={addOrderItem}
                className="mt-4 flex items-center gap-2 px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors"
              >
                <Plus className="h-4 w-4" />
                Добавить позицию
              </button>
            </div>
          </div>

          {/* Боковая колонка */}
          <div className="w-80 space-y-6">
            {/* Статус заказа */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-6">
                <Clock className="h-6 w-6 text-teal-600" />
                <h2 className="text-xl font-semibold text-gray-900">Статус заказа</h2>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Номер заказа</label>
                <div className="relative">
                  <input
                    type="text"
                    className="w-full px-3 py-2 pr-24 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={orderForm.orderNumber}
                    onChange={(e) => handleOrderChange('orderNumber', e.target.value)}
                    placeholder="Введите номер заказа"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const generateOrderNumber = () => {
                        const prefix = 'SOF';
                        const year = new Date().getFullYear();
                        const random = Math.floor(Math.random() * 9999).toString().padStart(4, '0');
                        return `${prefix}-${year}-${random}`;
                      };
                      handleOrderChange('orderNumber', generateOrderNumber());
                    }}
                    className="absolute right-1 top-1 bottom-1 px-2 py-1 bg-teal-600 text-white rounded text-xs font-medium hover:bg-teal-700 transition-colors"
                  >
                    Генерировать
                  </button>
                </div>
              </div>
              
              <div className="space-y-3">
                {orderStatuses.map((status) => {
                  const IconComponent = status.icon;
                  const isActive = orderForm.status === status.id;
                  
                  return (
                    <div
                      key={status.id}
                      onClick={() => handleStatusChange(status.id)}
                      className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all ${
                        isActive
                          ? `bg-${status.color}-50 border border-${status.color}-200`
                          : 'bg-gray-50 border border-gray-200 hover:bg-gray-100'
                      }`}
                    >
                      <IconComponent className={`h-5 w-5 ${
                        isActive ? `text-${status.color}-600` : 'text-gray-400'
                      }`} />
                      <div>
                        <div className={`font-medium ${
                          isActive ? `text-${status.color}-900` : 'text-gray-700'
                        }`}>
                          {status.title}
                        </div>
                        <div className={`text-sm ${
                          isActive ? `text-${status.color}-700` : 'text-gray-500'
                        }`}>
                          {status.description}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Информация о заказе */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-6">
                <Package className="h-6 w-6 text-teal-600" />
                <h2 className="text-xl font-semibold text-gray-900">Информация о заказе</h2>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Менеджер</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    value={orderForm.manager}
                    readOnly
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Дата создания</label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    value={orderForm.creationDate}
                    readOnly
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Срок выполнения</label>
                  <input
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={orderForm.deadline}
                    onChange={(e) => handleOrderChange('deadline', e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Приоритет</label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"
                    value={orderForm.priority}
                    onChange={(e) => handleOrderChange('priority', e.target.value)}
                  >
                    <option value="low">Низкий</option>
                    <option value="normal">Средний</option>
                    <option value="high">Высокий</option>
                    <option value="urgent">Срочный</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateOrderNew;
